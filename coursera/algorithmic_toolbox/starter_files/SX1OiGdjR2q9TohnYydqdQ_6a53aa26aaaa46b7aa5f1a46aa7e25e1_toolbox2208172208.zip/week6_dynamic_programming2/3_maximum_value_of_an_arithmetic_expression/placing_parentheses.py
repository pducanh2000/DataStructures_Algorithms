def evaluate(a, b, op):
    if op == '+':
        return a + b
    elif op == '-':
        return a - b
    elif op == '*':
        return a * b
    else:
        assert False


def maximum_value(dataset):
    # write your code here
    return 0


if __name__ == "__main__":
    print(maximum_value(input()))
