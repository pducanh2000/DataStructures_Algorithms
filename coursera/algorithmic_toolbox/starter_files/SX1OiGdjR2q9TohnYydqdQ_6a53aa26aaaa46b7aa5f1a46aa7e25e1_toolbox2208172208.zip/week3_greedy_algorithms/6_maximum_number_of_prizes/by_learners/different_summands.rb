#!/usr/bin/env ruby
# by Andronik Ordian

def optimal_summands(n)
  summands = []
  #write your code here
  summands
end

if __FILE__ == $0
  n = gets.to_i
  summands = optimal_summands(n)
  puts "#{summands.size}"
  puts "#{summands.join(' ')}"
end